<?php


include "connect.php";


getAllData("users" , "1 = 1");


// $subject = 'موضوع البريد الإلكتروني';
// $body = 'هذه رسالة اختبار في الجسم.';
// $sendto = 'tawafmesar@gmail.com';

// sendEmail($subject, $body, $sendto);

?>